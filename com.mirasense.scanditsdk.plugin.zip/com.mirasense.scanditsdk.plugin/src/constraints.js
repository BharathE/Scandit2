cordova.define("com.mirasense.scanditsdk.plugin.Constraints", function(require, exports, module) {

function Constraints() {
}

module.exports = Constraints;
});
