cordova.define("com.mirasense.scanditsdk.plugin.Callbacks", function(require, exports, module) {

function Callbacks() {
}

module.exports = Callbacks;

});
