cordova.define("com.mirasense.scanditsdk.plugin.Point", function(require, exports, module) {

function Point(x, y) {
	this.x = x;
	this.y = y;
}

module.exports = Point;
});
